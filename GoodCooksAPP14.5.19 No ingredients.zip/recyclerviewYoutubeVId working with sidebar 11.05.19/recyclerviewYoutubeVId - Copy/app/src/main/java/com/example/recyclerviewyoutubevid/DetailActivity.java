package com.example.recyclerviewyoutubevid;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import static com.example.recyclerviewyoutubevid.MainActivity.EXTRA_CREATOR;
import static com.example.recyclerviewyoutubevid.MainActivity.EXTRA_INGREDIENTS;
import static com.example.recyclerviewyoutubevid.MainActivity.EXTRA_LIKES;
import static com.example.recyclerviewyoutubevid.MainActivity.EXTRA_RECIPE_ID;
import static com.example.recyclerviewyoutubevid.MainActivity.EXTRA_SOCIAL_RANK;
import static com.example.recyclerviewyoutubevid.MainActivity.EXTRA_SOURCE_URL;
import static com.example.recyclerviewyoutubevid.MainActivity.EXTRA_TITLE;
import static com.example.recyclerviewyoutubevid.MainActivity.EXTRA_URL;

public class DetailActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        Intent intent = getIntent();
        String imageUrl = intent.getStringExtra(EXTRA_URL);
        String creatorName = intent.getStringExtra(EXTRA_CREATOR);
        int likeCount = intent.getIntExtra(EXTRA_LIKES, 0);
        int socialRank = intent.getIntExtra(EXTRA_SOCIAL_RANK, 0);
        String title = intent.getStringExtra(EXTRA_TITLE);
        String recipeId = intent.getStringExtra(EXTRA_RECIPE_ID);
        String ingredients = intent.getStringExtra(EXTRA_INGREDIENTS);
        String source_url = intent.getStringExtra(EXTRA_SOURCE_URL);

        ImageView imageView = findViewById(R.id.image_view_detail);
        TextView textViewCreator = findViewById(R.id.text_view_creator_detail);
        //TextView textViewLikes = findViewById(R.id.text_view_like_detail);
        TextView textViewSocialRank = findViewById(R.id.text_view_socialRankActivityDetail);
        TextView textViewtitle = findViewById(R.id.text_view_title);
        Picasso.with(this).load(imageUrl).fit().centerInside().into(imageView);
        textViewCreator.setText(creatorName);
        textViewtitle.setText(title);


        String socialRankString = Integer.toString(socialRank);
        textViewSocialRank.setText(String.format("Social rank: %s", socialRankString));

        TextView textViewSource_url = findViewById(R.id.text_view_source_url);
        textViewSource_url.setText(String.format("Source Link: %s", source_url));

        //textViewLikes.setText("Likes: " + likeCount);
        //try{
            //textViewSocialRank.setText(socialRank);
       // catch{
           // NullPointerException;
          // }

        TextView textViewingredients = findViewById(R.id.text_view_ingredients);
        textViewingredients.setText(ingredients);
    }
}
