package com.example.recyclerviewyoutubevid;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.SearchView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.SearchEvent;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.Response.ErrorListener;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


import java.util.ArrayList;
import java.util.List;

import static java.lang.System.exit;

public class MainActivity extends AppCompatActivity implements ExampleAdapter.OnItemClickListener {
    public static final String EXTRA_URL = "imageUrl";
    public static final String EXTRA_CREATOR = "creatorName";
    public static final String EXTRA_LIKES = "likeCount";
    public static final String TAG = "MainActivity";
    public static final String EXTRA_SOCIAL_RANK = "socialRank";

    private RecyclerView mRecyclerView;
    private ExampleAdapter mExampleAdapter;
    private ArrayList<ExampleItem> mExampleList;
    private RequestQueue mRequestQueue;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {


        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.options_menu,menu);

        SearchView searchView =(SearchView) menu.findItem(R.id.search).getActionView();
        searchView.setQueryHint("search recipe");

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                getMovies(s);
                Log.d("searchview",s);

                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                return false;
            }
        });

        return true;

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mRecyclerView = findViewById(R.id.recycler_view);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        mExampleList = new ArrayList<>();

        mRequestQueue = Volley.newRequestQueue(this);
        //ExampleAdapter.notifyDataSetChanged();
        parseJSON();
        //getMovies("Watermelon");
    }

    private void parseJSON() {
        //String url = "https://www.food2fork.com/api/search?key=9dfcbc5c7a9d79d5f50e4d5f00dee2dc";
        //String url = "https://pixabay.com/api/?key=5303976-fd6581ad4ac165d1b75cc15b3&q=kitten&image_type=photo&pretty=true";
        String url = "https://www.food2fork.com/api/search?key=9dfcbc5c7a9d79d5f50e4d5f00dee2dc&sort=t";
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {

                            //the name should be "recipes" not "hits", this is the name
                            //of the json array sent back by the api call
                            JSONArray jsonArray = response.getJSONArray("recipes");

                            Log.d("mainactivity", "try block called");

                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject recipe = jsonArray.getJSONObject(i);


                                String creatorName = recipe.getString("publisher");
                                String imageUrl = recipe.getString("image_url");
                                //int likeCount = recipe.getInt("social_rank");
                                int socialRank = recipe.getInt("social_rank");
                                String title = recipe.getString("title");
                               // mExampleList.add(new ExampleItem(imageUrl, creatorName, title));
                                mExampleList.add(new ExampleItem(imageUrl, creatorName, title, socialRank));
                                //mExampleList.add(new ExampleItem(title, likeCount));
                            }

                            mExampleAdapter = new ExampleAdapter(MainActivity.this, mExampleList);
                            mRecyclerView.setAdapter(mExampleAdapter);
                            mExampleAdapter.setOnItemClickListener(MainActivity.this);

                        } catch (JSONException e) {
                            e.printStackTrace();
                            //exit(1);
                        }
                    }

                }, new ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

        mRequestQueue.add(request);
    }

    @Override
    public void onItemClick(int position) {
        Intent detailIntent = new Intent(this, DetailActivity.class);
        ExampleItem clickedItem = mExampleList.get(position);

        detailIntent.putExtra(EXTRA_URL, clickedItem.getImageUrl());
        //detailIntent.putExtra(EXTRA_LIKES, clickedItem.getLikeCount());
        detailIntent.putExtra(EXTRA_CREATOR, clickedItem.getCreator());
        detailIntent.putExtra(EXTRA_SOCIAL_RANK, clickedItem.getSocialRank());
        startActivity(detailIntent);
    }

    private void getMovies(String s) {
        //String url = "https://www.food2fork.com/api/search?key=9dfcbc5c7a9d79d5f50e4d5f00dee2dc";
        //String url = "https://pixabay.com/api/?key=5303976-fd6581ad4ac165d1b75cc15b3&q=kitten&image_type=photo&pretty=true";
        //String url = "https://www.food2fork.com/api/search?key=9dfcbc5c7a9d79d5f50e4d5f00dee2dc&sort=t";
        mExampleList.clear();
        String url = "https://www.food2fork.com/api/search?key=9dfcbc5c7a9d79d5f50e4d5f00dee2dc&q=";
        url = url+s;
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {

                            //the name should be "recipes" not "hits", this is the name
                            //of the json array sent back by the api call
                            JSONArray jsonArray = response.getJSONArray("recipes");

                            Log.d("mainactivity", "try block called");

                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject recipe = jsonArray.getJSONObject(i);


                                String creatorName = recipe.getString("publisher");
                                String imageUrl = recipe.getString("image_url");
                                //int likeCount = recipe.getInt("social_rank");
                                int socialRank = recipe.getInt("social_rank");
                                String title = recipe.getString("title");
                                // mExampleList.add(new ExampleItem(imageUrl, creatorName, title));
                                mExampleList.add(new ExampleItem(imageUrl, creatorName, title, socialRank));
                                //mExampleList.add(new ExampleItem(title, likeCount));
                            }

                            mExampleAdapter = new ExampleAdapter(MainActivity.this, mExampleList);
                            mRecyclerView.setAdapter(mExampleAdapter);
                            mExampleAdapter.setOnItemClickListener(MainActivity.this);

                        } catch (JSONException e) {
                            e.printStackTrace();
                            //exit(1);
                        }
                    }

                }, new ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

        mRequestQueue.add(request);
    }

   /* public List<ExampleItem> getMovies(String searchTerm) {
        ExampleItem.clear();
        String url = "https://www.food2fork.com/api/search?key=9dfcbc5c7a9d79d5f50e4d5f00dee2dc&q=";
        //String url_right = "&sort=t";
        //String
        //https://www.food2fork.com/api/search?key=9dfcbc5c7a9d79d5f50e4d5f00dee2dc&q=apple%20pie&
        url = url+searchTerm;
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {

            try{
                JSONArray recipesArray = response.getJSONArray("Search");

                for (int i = 0; i < jsonArray.length(); i++) {

                    JSONObject recipe = recipesArray.getJSONObject(i);
                    String creatorName = recipe.getString("publisher");
                    String imageUrl = recipe.getString("image_url");
                    //int likeCount = recipe.getInt("social_rank");
                    int socialRank = recipe.getInt("social_rank");
                    String title = recipe.getString("title");
                    mExampleList.add(new ExampleItem(imageUrl, creatorName, title, socialRank));


                }

                mExampleAdapter = new ExampleAdapter(MainActivity.this, mExampleList);
                mRecyclerView.setAdapter(mExampleAdapter);
                mExampleAdapter.setOnItemClickListener(MainActivity.this);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }, new ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {
            error.printStackTrace();
        }
    });

    mRequestQueue.add(request);
    }*/
}